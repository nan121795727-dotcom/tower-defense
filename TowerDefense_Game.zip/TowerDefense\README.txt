========================================
       Tower Defense Game
========================================

How to play:
1. Double-click "start_game.bat"
2. Wait for browser to open automatically
3. If browser doesn't open, visit: http://localhost:8080
4. Keep the black window open while playing

Controls:
- Drag towers from shop to place them
- Drag same towers together to merge/upgrade
- Only Level 1 towers can be dragged for merging

Tips:
- Place towers at corners for maximum coverage
- Ice mage slows enemies (better at higher levels)
- Cannon has splash damage
- Lightning tower chains to multiple enemies

Have fun!
========================================